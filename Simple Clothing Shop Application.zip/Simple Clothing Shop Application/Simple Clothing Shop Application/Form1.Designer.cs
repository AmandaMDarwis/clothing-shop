﻿namespace Simple_Clothing_Shop_Application
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dgvCart = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbSubTotal = new System.Windows.Forms.TextBox();
            this.tbTotal = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnAddKiri = new System.Windows.Forms.Button();
            this.btnAddTengah = new System.Windows.Forms.Button();
            this.btnAddKanan = new System.Windows.Forms.Button();
            this.lbKiri = new System.Windows.Forms.Label();
            this.lbTengah = new System.Windows.Forms.Label();
            this.lbKanan = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbHargaKanan = new System.Windows.Forms.Label();
            this.lbHargaTengah = new System.Windows.Forms.Label();
            this.lbHargaKiri = new System.Windows.Forms.Label();
            this.btnRemove = new System.Windows.Forms.Button();
            this.lbUpload = new System.Windows.Forms.Label();
            this.btnUpload = new System.Windows.Forms.Button();
            this.pbUpload = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbItemName = new System.Windows.Forms.TextBox();
            this.tbItemPrice = new System.Windows.Forms.TextBox();
            this.pnlUpload = new System.Windows.Forms.Panel();
            this.btnAddUpload = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbUpload)).BeginInit();
            this.pnlUpload.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1153, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(136, 26);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelriesToolStripMenuItem
            // 
            this.jewelriesToolStripMenuItem.Name = "jewelriesToolStripMenuItem";
            this.jewelriesToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.jewelriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelriesToolStripMenuItem.Click += new System.EventHandler(this.jewelriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // dgvCart
            // 
            this.dgvCart.AllowUserToDeleteRows = false;
            this.dgvCart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCart.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvCart.Location = new System.Drawing.Point(697, 56);
            this.dgvCart.Name = "dgvCart";
            this.dgvCart.RowHeadersWidth = 51;
            this.dgvCart.RowTemplate.Height = 24;
            this.dgvCart.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCart.Size = new System.Drawing.Size(417, 259);
            this.dgvCart.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(696, 329);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 22);
            this.label1.TabIndex = 3;
            this.label1.Text = "Sub-Total : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(738, 369);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 22);
            this.label2.TabIndex = 4;
            this.label2.Text = "Total : ";
            // 
            // tbSubTotal
            // 
            this.tbSubTotal.Location = new System.Drawing.Point(819, 331);
            this.tbSubTotal.Name = "tbSubTotal";
            this.tbSubTotal.Size = new System.Drawing.Size(154, 22);
            this.tbSubTotal.TabIndex = 5;
            // 
            // tbTotal
            // 
            this.tbTotal.Location = new System.Drawing.Point(819, 371);
            this.tbTotal.Name = "tbTotal";
            this.tbTotal.Size = new System.Drawing.Size(154, 22);
            this.tbTotal.TabIndex = 6;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(20, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(173, 259);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(240, 13);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(173, 259);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(461, 13);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(173, 259);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // btnAddKiri
            // 
            this.btnAddKiri.Location = new System.Drawing.Point(20, 366);
            this.btnAddKiri.Name = "btnAddKiri";
            this.btnAddKiri.Size = new System.Drawing.Size(104, 33);
            this.btnAddKiri.TabIndex = 10;
            this.btnAddKiri.Text = "Add to cart";
            this.btnAddKiri.UseVisualStyleBackColor = true;
            this.btnAddKiri.Click += new System.EventHandler(this.btnAddKiri_Click);
            // 
            // btnAddTengah
            // 
            this.btnAddTengah.Location = new System.Drawing.Point(240, 366);
            this.btnAddTengah.Name = "btnAddTengah";
            this.btnAddTengah.Size = new System.Drawing.Size(104, 33);
            this.btnAddTengah.TabIndex = 11;
            this.btnAddTengah.Text = "Add to cart";
            this.btnAddTengah.UseVisualStyleBackColor = true;
            this.btnAddTengah.Click += new System.EventHandler(this.btnAddTengah_Click);
            // 
            // btnAddKanan
            // 
            this.btnAddKanan.Location = new System.Drawing.Point(461, 366);
            this.btnAddKanan.Name = "btnAddKanan";
            this.btnAddKanan.Size = new System.Drawing.Size(104, 33);
            this.btnAddKanan.TabIndex = 12;
            this.btnAddKanan.Text = "Add to cart";
            this.btnAddKanan.UseVisualStyleBackColor = true;
            this.btnAddKanan.Click += new System.EventHandler(this.btnAddKanan_Click);
            // 
            // lbKiri
            // 
            this.lbKiri.AutoSize = true;
            this.lbKiri.Location = new System.Drawing.Point(17, 295);
            this.lbKiri.Name = "lbKiri";
            this.lbKiri.Size = new System.Drawing.Size(44, 16);
            this.lbKiri.TabIndex = 13;
            this.lbKiri.Text = "label3";
            // 
            // lbTengah
            // 
            this.lbTengah.AutoSize = true;
            this.lbTengah.Location = new System.Drawing.Point(237, 295);
            this.lbTengah.Name = "lbTengah";
            this.lbTengah.Size = new System.Drawing.Size(44, 16);
            this.lbTengah.TabIndex = 14;
            this.lbTengah.Text = "label3";
            // 
            // lbKanan
            // 
            this.lbKanan.AutoSize = true;
            this.lbKanan.Location = new System.Drawing.Point(458, 295);
            this.lbKanan.Name = "lbKanan";
            this.lbKanan.Size = new System.Drawing.Size(44, 16);
            this.lbKanan.TabIndex = 15;
            this.lbKanan.Text = "label3";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbHargaKanan);
            this.panel1.Controls.Add(this.lbHargaTengah);
            this.panel1.Controls.Add(this.lbHargaKiri);
            this.panel1.Controls.Add(this.lbKanan);
            this.panel1.Controls.Add(this.lbTengah);
            this.panel1.Controls.Add(this.lbKiri);
            this.panel1.Controls.Add(this.btnAddKanan);
            this.panel1.Controls.Add(this.btnAddTengah);
            this.panel1.Controls.Add(this.btnAddKiri);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(13, 42);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(663, 419);
            this.panel1.TabIndex = 16;
            // 
            // lbHargaKanan
            // 
            this.lbHargaKanan.AutoSize = true;
            this.lbHargaKanan.Location = new System.Drawing.Point(458, 313);
            this.lbHargaKanan.Name = "lbHargaKanan";
            this.lbHargaKanan.Size = new System.Drawing.Size(44, 16);
            this.lbHargaKanan.TabIndex = 18;
            this.lbHargaKanan.Text = "label3";
            // 
            // lbHargaTengah
            // 
            this.lbHargaTengah.AutoSize = true;
            this.lbHargaTengah.Location = new System.Drawing.Point(237, 313);
            this.lbHargaTengah.Name = "lbHargaTengah";
            this.lbHargaTengah.Size = new System.Drawing.Size(44, 16);
            this.lbHargaTengah.TabIndex = 17;
            this.lbHargaTengah.Text = "label3";
            // 
            // lbHargaKiri
            // 
            this.lbHargaKiri.AutoSize = true;
            this.lbHargaKiri.Location = new System.Drawing.Point(17, 313);
            this.lbHargaKiri.Name = "lbHargaKiri";
            this.lbHargaKiri.Size = new System.Drawing.Size(44, 16);
            this.lbHargaKiri.TabIndex = 16;
            this.lbHargaKiri.Text = "label3";
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(1031, 327);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(83, 31);
            this.btnRemove.TabIndex = 17;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // lbUpload
            // 
            this.lbUpload.AutoSize = true;
            this.lbUpload.Location = new System.Drawing.Point(21, 20);
            this.lbUpload.Name = "lbUpload";
            this.lbUpload.Size = new System.Drawing.Size(93, 16);
            this.lbUpload.TabIndex = 18;
            this.lbUpload.Text = "Upload Image";
            // 
            // btnUpload
            // 
            this.btnUpload.Location = new System.Drawing.Point(134, 13);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(83, 31);
            this.btnUpload.TabIndex = 19;
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // pbUpload
            // 
            this.pbUpload.Location = new System.Drawing.Point(24, 57);
            this.pbUpload.Name = "pbUpload";
            this.pbUpload.Size = new System.Drawing.Size(173, 259);
            this.pbUpload.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbUpload.TabIndex = 19;
            this.pbUpload.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(225, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "Item Name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(225, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "Item Price :";
            // 
            // tbItemName
            // 
            this.tbItemName.Location = new System.Drawing.Point(228, 88);
            this.tbItemName.Name = "tbItemName";
            this.tbItemName.Size = new System.Drawing.Size(154, 22);
            this.tbItemName.TabIndex = 22;
            this.tbItemName.TextChanged += new System.EventHandler(this.tbItemName_TextChanged);
            // 
            // tbItemPrice
            // 
            this.tbItemPrice.Location = new System.Drawing.Point(228, 161);
            this.tbItemPrice.Name = "tbItemPrice";
            this.tbItemPrice.Size = new System.Drawing.Size(154, 22);
            this.tbItemPrice.TabIndex = 23;
            this.tbItemPrice.TextChanged += new System.EventHandler(this.tbItemPrice_TextChanged);
            this.tbItemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbItemPrice_KeyPress);
            // 
            // pnlUpload
            // 
            this.pnlUpload.Controls.Add(this.btnAddUpload);
            this.pnlUpload.Controls.Add(this.tbItemPrice);
            this.pnlUpload.Controls.Add(this.tbItemName);
            this.pnlUpload.Controls.Add(this.label4);
            this.pnlUpload.Controls.Add(this.label3);
            this.pnlUpload.Controls.Add(this.pbUpload);
            this.pnlUpload.Controls.Add(this.btnUpload);
            this.pnlUpload.Controls.Add(this.lbUpload);
            this.pnlUpload.Location = new System.Drawing.Point(16, 31);
            this.pnlUpload.Name = "pnlUpload";
            this.pnlUpload.Size = new System.Drawing.Size(411, 330);
            this.pnlUpload.TabIndex = 24;
            // 
            // btnAddUpload
            // 
            this.btnAddUpload.Location = new System.Drawing.Point(228, 216);
            this.btnAddUpload.Name = "btnAddUpload";
            this.btnAddUpload.Size = new System.Drawing.Size(104, 33);
            this.btnAddUpload.TabIndex = 19;
            this.btnAddUpload.Text = "Add to cart";
            this.btnAddUpload.UseVisualStyleBackColor = true;
            this.btnAddUpload.Click += new System.EventHandler(this.btnAddUpload_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 489);
            this.Controls.Add(this.pnlUpload);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tbTotal);
            this.Controls.Add(this.tbSubTotal);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvCart);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbUpload)).EndInit();
            this.pnlUpload.ResumeLayout(false);
            this.pnlUpload.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.DataGridView dgvCart;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbSubTotal;
        private System.Windows.Forms.TextBox tbTotal;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnAddKiri;
        private System.Windows.Forms.Button btnAddTengah;
        private System.Windows.Forms.Button btnAddKanan;
        private System.Windows.Forms.Label lbKiri;
        private System.Windows.Forms.Label lbTengah;
        private System.Windows.Forms.Label lbKanan;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelriesToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbHargaKiri;
        private System.Windows.Forms.Label lbHargaKanan;
        private System.Windows.Forms.Label lbHargaTengah;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Label lbUpload;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.PictureBox pbUpload;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbItemName;
        private System.Windows.Forms.TextBox tbItemPrice;
        private System.Windows.Forms.Panel pnlUpload;
        private System.Windows.Forms.Button btnAddUpload;
    }
}

